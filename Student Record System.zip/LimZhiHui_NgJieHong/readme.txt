Group Member 1:

Name: LIM ZHI HUI
Student ID: 2206389
Course: CS
Practical Session: Friday, 2.30PM - 4.30PM
Practical Group: P2
Tutor: Mr.Goh Chuan Meng


Group Member 2:

Name: NG JIE HONG
Student ID: 2302228
Course: CS
Practical Session: Friday, 2.30PM - 4.30PM
Tutor: Mr.Goh Chuan Meng


